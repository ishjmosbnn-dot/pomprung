---
name: Fresh Culinary Kitchen
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3e4a3d'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#6e7b6c'
  outline-variant: '#bdcaba'
  surface-tint: '#006e2d'
  primary: '#006b2c'
  on-primary: '#ffffff'
  primary-container: '#00873a'
  on-primary-container: '#f7fff2'
  inverse-primary: '#62df7d'
  secondary: '#855300'
  on-secondary: '#ffffff'
  secondary-container: '#fea619'
  on-secondary-container: '#684000'
  tertiary: '#466252'
  on-tertiary: '#ffffff'
  tertiary-container: '#5e7b6a'
  on-tertiary-container: '#f6fff6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#7ffc97'
  primary-fixed-dim: '#62df7d'
  on-primary-fixed: '#002109'
  on-primary-fixed-variant: '#005320'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#caead6'
  tertiary-fixed-dim: '#afceba'
  on-tertiary-fixed: '#042014'
  on-tertiary-fixed-variant: '#314d3e'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system delivers an appetizing, hygienic, and modern food delivery experience centered on freshness, reliability, and visual indulgence. Designed for fast-paced urban dining, meal-kit pre-orders, and on-demand ready-to-eat selections, the UI emphasizes immaculate ingredient presentation, frictionless checkout, and effortless readability in both Thai and English.

The overarching design style blends **Modern Culinary Minimalism** with **Organic Tactility**:
- **Generous Whitespace & Luminous Canvases:** Clean whites and subtle cool neutrals allow full-color food photography to command attention, evoking clean kitchen prep areas and farm-fresh ingredients.
- **Micro-tactility:** Soft, pillowy touch targets with subtle elevation communicate responsiveness without visual clutter.
- **Friendly Precision:** Rounded geometries, pill-shaped tags, and clear typography establish a warm yet highly efficient purchasing loop.

## Colors

The palette reinforces vitality, appetite stimulation, and crisp legibility across high-density menus:

- **Primary Green (`#16A34A` / deep `#15803D`):** Reflects crisp fresh herbs, farm produce, and kitchen vitality. Used exclusively for primary action triggers (Add to Basket, Place Order), order tracking milestones, and brand accents.
- **Warm Amber Accent (`#F59E0B`):** Invokes golden crusts, searing heat, and umami. Reserved for star ratings, high-priority promotional badges, preparation timers, and limited-time offer highlights.
- **Mint Surface Tint (`#DCFCE7`):** A soft, restorative wash deployed as background fill for active filter states, dietary tags (Vegan/Healthy), and success notices.
- **Deep Slate Neutrals (`#0F172A` / `#334155`):** High-contrast, optical slate for Thai and Latin typography, ensuring high legibility over bright backgrounds without the eye-fatigue of harsh `#000000`.
- **Canvas & Surface Containers (`#FFFFFF`, `#F8FAFC`, `#F1F5F9`):** Multi-tier neutral surfaces separating categories, food card containers, and sticky checkout summaries.

## Typography

Typography prioritizes bilingual harmony between Thai and Latin scripts. When rendering Thai glyphs, font fallbacks must systematically prioritize contemporary loopless typefaces (e.g., `Prompt`, `Noto Sans Thai`) to pair seamlessly with `Plus Jakarta Sans`.

- **Spacious Line Heights:** Thai vowels and tonal marks (วรรณยุกต์) necessitate extended vertical bounding boxes. All line heights maintain at least a 1.4x to 1.6x ratio relative to font size to avoid accent clipping.
- **Numbers & Pricing:** Monetary figures and nutritional values use bold tabular figures to allow instant scanning across menu tiers and cart totals.
- **Scale Modulation:** Mobile screen constraints automatically downscale display headers while keeping body text at a minimum of 14px to safeguard ordering speed and accessibility on handheld devices.

## Layout & Spacing

The layout is built on an **8pt progressive rhythm** combined with an elastic grid:

- **Mobile Viewports (<640px):** 4-column layout with 16px (`1rem`) outer canvas margins and 12px (`0.75rem`) gutters. Menu items default to single-column cards or dense list rows with large leading image thumbs.
- **Tablet / Large Handhelds (640px - 1024px):** 8-column layout with 24px (`1.5rem`) margins. Dishes reflow into a 2-column or 3-column masonry/grid.
- **Desktop / Web Storefront (>1024px):** 12-column layout with a constrained maximum container width of `1200px`. Uses a persistent split layout: 8 columns for interactive menu browsing and 4 columns for sticky cart, dietary filter controls, and kitchen status.
- **Safe Area Insets:** Sticky checkout bars and bottom navigators strictly account for mobile notch and home-indicator safe areas (`env(safe-area-inset-bottom)` + `space-md`).

## Elevation & Depth

Visual depth is achieved through **ambient culinary shadows** and layered tonal containers, eschewing heavy borders:

- **Level 0 (Flat):** Neutral background canvases (`#F8FAFC`).
- **Level 1 (Card & Section Depth):** Menu cards and recipe containers sit on `#FFFFFF` elevated with an ultra-soft, warm ambient drop shadow: `0 4px 20px -2px rgba(15, 23, 42, 0.05)`.
- **Level 2 (Interactive Floating Elements):** Quantity adjusters, category chips during horizontal drag, and sticky header bars: `0 8px 24px -4px rgba(15, 23, 42, 0.08)`.
- **Level 3 (Modal Sheets & Sticky Bottom CTA):** Full order summary bars and bottom modification sheets: `0 -8px 32px -4px rgba(15, 23, 42, 0.12)`.
- **Atmospheric Tints:** Floating promotional banners and success confirmations feature a faint green ambient glow (`rgba(22, 163, 74, 0.15)`), signaling freshness and fulfillment.

## Shapes

The design uses **Rounded** geometry with selective full-pill accents:

- **Cards & Containers (`rounded-lg` / 1rem):** Food items, order track modules, and modal containers use 16px corner rounding, creating an approachable, friendly silhouette.
- **Badges, Pills & Action Triggers (`rounded-full` / 9999px):** Dietary tags (e.g., "เผ็ดน้อย", "Halal", "Chef's Pick"), category filter pills, circular quantity steppers (`+` / `-`), and primary sticky CTAs adopt continuous organic curves.
- **Food Photography Windows:** Images utilize proportional rounding matching their parent container on the top edges, maintaining visual unity with card perimeters.

## Components

### Buttons
- **Primary Action (Add to Basket / Checkout):** Solid `#16A34A` background with crisp `#FFFFFF` text. Minimum touch target height of 48px on mobile (52px preferred for final checkout). Pill-shaped or 12px rounded. Hover state darkens to `#15803D`.
- **Secondary / Ghost:** `#DCFCE7` background with `#15803D` text for low-priority actions (e.g., "Add Notes", "Customise").
- **Quantity Steppers:** Circular floating pill cluster (`-` `Qty` `+`) with high tactile hit areas (min 36x36px per button).

### Chips & Badges
- **Category Filter Chips:** Pill-shaped, borderless `#F1F5F9` background with `#334155` text in unselected state. Selected state transitions instantly to `#16A34A` with pure white text.
- **Rating / Promo Tag:** Compact pill using amber tint (`#FEF3C7`) with bold `#D97706` typography and an inline star glyph.

### Food & Recipe Cards
- **Product Card:** Pure white background surface, subtle Level 1 shadow, overflow-hidden. Comprises an edge-to-edge 4:3 or 1:1 appetizing image container, bold dish title, subtle Thai descriptor, price display in bold slate, and a floating circular quick-add icon positioned bottom-right of the image.
- **Customization Modal / Bottom Sheet:** Draggable sheet featuring ingredient checkboxes, radio options for portion sizes, and dynamic total price updating in real time.

### Lists & Cart Rows
- Flat `#FFFFFF` line items separated by soft 1px hairline dividers (`#F1F5F9`). Includes thumbnail preview (64x64px, 8px rounded), dish title, inline customization list in muted slate (`#64748B`), and stepper controls aligned to the right.

### Input Fields
- Delivery address and special instruction fields feature an inset `#F8FAFC` fill, 12px rounded corners, and no visible outer border until focused. Focus switches border to 1.5px solid `#16A34A` with an ambient mint focus ring.